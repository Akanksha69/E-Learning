#include<stdio.h>
#include<string>
#include<iostream>
#include<fstream>
#include<limits>


using namespace std;

void quiz();
void course();
void video();

void save_user(const std::string &username, const std::string &password);

void login();
void register_user();
void main_menu();


int guess;
int total=0;
//class question;
class question{
private:
    string question_form;
    string answer_1;
    string answer_2;
    string answer_3;
    string answer_4;

    int correct;
    int score;

public:
    void setvalues(string,string,string,string,string,int,int);
    void askQuestion();

};
int main()
{

    cout<<" ********************************* "<<endl;
    cout<<" *                               * "<<endl;
    cout<<" *   *WELCOM TO E-LEARNING*      * "<<endl;
    cout<<" *                               * "<<endl;
    cout<<" ********************************* "<<endl;
    cout<<endl;

    int option;
    cout<<"Enter optio to select:"<<endl<<"1.register/login"<<endl<<"2.quiz"<<endl<<"3.courses"<<endl<<"4.exit"<<endl;
    cin>>option;
    switch(option)
    {
        case 1:
            cout<<"If already registered-->login"<<endl;
            main_menu();
            break;

        case 2:
            cout<<"Attempt quiz."<<endl;
            quiz();
            break;
        case 3:
            cout<<"browse course."<<endl;
            course();
            break;
        case 4:
            exit;

    }
}

void quiz(){

        question q1;
        question q2;

        q1.setvalues("Sanjeev Chopra belongs to which game?",
                     "hockey",
                     "badminton",
                     "shot-put",
                     "javelline throw",
                     4,
                     10);
        q2.setvalues("Olympic 2020 held in which country?",
                     "India",
                     "Japan",
                     "Aouth Africa",
                     "None of the above",
                     2,
                     10);
        q1.askQuestion();
        q2.askQuestion();

        cout<<"Your total score is"<< total << endl;

    }

void question::setvalues(string q,string a1,string a2,string a3,string a4,int ca,int pa){
    question_form = q;
    answer_1 = a1;
    answer_2 = a2;
    answer_3 = a3;
    answer_4 = a4;
    correct = ca;
    score = pa;

}
void question::askQuestion(){
    cout<<endl;
    cout<<question_form <<endl;
    cout<<"1. "<<answer_1 <<endl;
    cout<<"2. "<<answer_2 <<endl;
    cout<<"3. "<<answer_3 <<endl;
    cout<<"4. "<<answer_4 <<endl;
    cout<<endl;
    cout<<"what is your answer ?"<<endl;
    cin>>guess;

    if(guess==correct){
        cout<<endl;
        cout<<"Great! Correct. "<<endl;
        total=total+score;
        cout<<"score:"<<score<<endl;
        cout<<endl;

    }
    else{
        cout<<endl;
        cout<<"oh NO! Wrong."<<endl;
        cout<<"score:0"<<score<<endl;
        cout<<endl;

    }

}
void course(){
    int co;
    cout<<"Enter course to select:"<<endl<<"1.JAVA"<<endl<<"2.PYTHON"<<endl<<"3.C++"<<endl;
    cin>>co;
    switch(co)
    {
        case 1:
            cout<<"JAVA"<<endl;
            video();
            break;

        case 2:
            cout<<"PYTHON."<<endl;
            video();
            break;
        case 3:
            cout<<"C++"<<endl;
            video();
            break;
        case 4:
            exit;

    }

}
void video(){
    cout<<"COMING SOON!!!...."<<endl;
}


template <typename T>
T get_input(const string &strQuery)
{
    cout << strQuery << "\n> ";
    T out = T();

    while (!(cin >> out)) {
        cin.clear();
        cin.ignore(numeric_limits <streamsize>::max(), '\n');
        cout << "Error!" "\n";
        cout << strQuery << "\n> ";
    }

    return out;
}

string get_password()
{
    string password1 = get_input <std::string> ("Please enter your password.");
    string password2 = get_input <std::string> ("Please re-enter your password.");

    while (password1 != password2) {
        cout << "Error! Passwords do not match." "\n";
        password1 = get_input <std::string>("Please enter your password.");
        password2 = get_input <std::string>("Please re-enter your password.");
    }

    return password1;
}

string get_username()
{
    string username = get_input <std::string>("Please enter a username.");
    cout << "Username: \"" << username << "\"\n";

    while (get_input <int>("Confirm? [0|1]") != 1) {
        username = get_input <std::string>("Please enter a username.");
        cout << "Username: \"" << username << "\"\n";
    }

    return username;
}

void login()
{
    cout << "You are being logged in!" "\n";
}

void main_menu()
{
    int choice = get_input <int>(
        "Hello, Would you like to log in or register?" "\n"
        "[1] Login" "\n"
        "[2] Register" "\n"
        "[3] Exit");

    switch (choice)
    {
    case 1:
        login();
        break;
    case 2:
        register_user();
        break;
    }
}

void register_user()
{
    string username = get_username();
    string password = get_password();
    save_user(username, password);
}

void save_user(const string &username, const string &password)
{
    string filename = username + ".txt";
    ofstream file(filename);
    file << password << "\n";
}
